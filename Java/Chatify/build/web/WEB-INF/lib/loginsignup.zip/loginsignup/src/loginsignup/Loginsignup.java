/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginsignup;


public class Loginsignup {

  
    public static void main(String[] args) {
        // TODO code application logic here
        login LoginFrame =new login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null );// center
        
        
        
        
        
    }
    
}
