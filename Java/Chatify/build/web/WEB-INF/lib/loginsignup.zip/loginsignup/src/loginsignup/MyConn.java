/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginsignup;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class MyConn{
static Connection c;
	public static void getMyConn()throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/HospitalDB";
		c = DriverManager.getConnection(url,"root","1234");
	}
	public static void save(String sql)throws Exception{
		if(c==null)
			getMyConn();
		c.createStatement().executeUpdate(sql);
	}
	public static ResultSet serach(String sql)throws Exception{
		if(c==null)
			getMyConn();
		ResultSet rs = c.createStatement().executeQuery(sql);
		return rs;
	}


}